from django.apps import AppConfig


class OjdccrawlerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ojdccrawler'
